//: Playground - noun: a place where people can play

import UIKit
//create class for imageprocessor
class ImageProcessor {
    var image: RGBAImage
    var avgRed = 0
    var avgGreen = 0
    var avgBlue = 0
    
    init(image: UIImage){
        self.image = RGBAImage(image: image)!
    }
    
    func functions(filter: [String]){
        self.averages(self.image)
        
        for option in filter {//this will allow params to be called by specific string aka Switch cases
            switch option.lowercaseString {
            case "5 times green":
                self.makeGreener(self.image)
            case "5 times blue":
                self.makeBluer(self.image)
            case "5 times red":
                self.makeRedder(self.image)
            case "50% less bright":
                self.bright(self.image)
            case "black-white":
                self.bw(self.image)
            default:
                print("The filter", option.lowercaseString , "does not exist at the moment.")
            }
        }
    }
    //assign averages depending on specific image
    func averages(image: RGBAImage){//simple function used in modules
        var Red = 0
        var Green = 0
        var Blue = 0
        for y in 0..<image.height{
            for x in 0..<image.width{
                let index = y * image.width + x
                var pixel = image.pixels[index]
                Red = Red + Int(pixel.red)
                Green = Green + Int(pixel.green)
                Blue = Blue + Int(pixel.blue)
            }
        }
        let counter = image.width * image.height
        self.avgRed = Red/counter
        self.avgBlue = Blue/counter
        self.avgGreen = Green/counter
    }
    
    //greener!
    func makeGreener(image: RGBAImage){//filter to enhance green pixels by 5 times
        for y in 0..<self.image.height{
            for x in 0..<self.image.width{
                let index = y * self.image.width + x
                var pixel = self.image.pixels[index]
                let greenDiff = Int(pixel.green) - avgGreen
                if(greenDiff > 0){
                    pixel.green = UInt8( max(0,min(255,avgGreen + greenDiff*5 ) ) )
                    self.image.pixels[index] = pixel
                }
            }
        }
    }
    
    //make blue!
    func makeBluer(image: RGBAImage){//filter to enhance blue pixels by 5 times
        for y in 0..<self.image.height{
            for x in 0..<self.image.width{
                let index = y * self.image.width + x
                var pixel = self.image.pixels[index]
                let blueDiff = Int(pixel.blue) - avgBlue
                if(blueDiff > 0){
                    pixel.blue = UInt8( max(0,min(255,avgBlue + blueDiff*5 ) ) )
                    self.image.pixels[index] = pixel
                }
            }
        }
    }
    
    //make redder
    func makeRedder(image: RGBAImage){//filter to enhance red pixels by 5 times
        for y in 0..<self.image.height{
            for x in 0..<self.image.width{
                let index = y * self.image.width + x
                var pixel = self.image.pixels[index]
                let redDiff = Int(pixel.red) - avgRed
                if(redDiff > 0){
                    pixel.red = UInt8( max(0,min(255,avgRed + redDiff*5 ) ) )
                    self.image.pixels[index] = pixel
                }
            }
        }
    }
    
    //brightness
    func bright(image: RGBAImage){//decrease intensity of pixels by 50%
        let brightness = 0.50
        for y in 0..<self.image.height {
            for x in 0..<self.image.width {
                let index = y * self.image.width + x
                var pixel = self.image.pixels[index]
                let G = round(Double(pixel.green) * brightness) //decrease done here
                
                let B = round(Double(pixel.blue) * brightness) //decrease done here
                
                let R = round(Double(pixel.red) * brightness) //decrease done here
                
                pixel.green = UInt8( max (0, min (255, G)))
                
                pixel.blue = UInt8( max (0, min (255, B)))
                
                pixel.red = UInt8( max (0, min (255, R)))
                self.image.pixels[index] = pixel
            }
        }
    }
    
    //black and white
    func bw(image: RGBAImage){
        for y in 0..<self.image.height {
            for x in 0..<self.image.width {
                let index = y * self.image.width + x
                var pixel = self.image.pixels[index]
                
                let mid = 0.299 * Double(pixel.red) + 0.587 * Double(pixel.green) + 0.114 * Double(pixel.blue)
                let gray = round(mid)
                
                pixel.green = UInt8(gray)
                
                pixel.blue = UInt8(gray)
                
                pixel.red = UInt8(gray)
                
                self.image.pixels[index] = pixel
            }
        }
    }
    func view() -> UIImage {//create ability to see new created image
        return self.image.toUIImage()!
    }
}


//test the code!
//
//og image
let image = UIImage(named: "sample")!
//make image instances for each of 5 filters
let one = ImageProcessor(image: image)
let two = ImageProcessor(image: image)
let three = ImageProcessor(image: image)
let four = ImageProcessor(image: image)
let five = ImageProcessor(image: image)

//how to use filter
//
//one
//-------------------------------
one.functions(["5 times green"])
one.view()
//
//two
//-----------------------------
two.functions(["5 times red"])
two.view()
//
//three
//-----------------------------
three.functions(["5 times blue"])
three.view()
//
//four
//-----------------------------
four.functions(["50% less bright"])
four.view()
//
//five
//----------------------------
five.functions(["black-white"])
five.view()


